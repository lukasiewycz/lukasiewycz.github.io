package org.xtext.example.mydsl;

import java.util.List;

import org.eclipse.xtext.xbase.scoping.batch.ImplicitlyImportedFeatures;

class MyImplicitlyImportedTypes extends ImplicitlyImportedFeatures {
	
	protected List<Class<?>> getExtensionClasses() {
		List<Class<?>> list = super.getExtensionClasses();
		return list;
	}
	
}