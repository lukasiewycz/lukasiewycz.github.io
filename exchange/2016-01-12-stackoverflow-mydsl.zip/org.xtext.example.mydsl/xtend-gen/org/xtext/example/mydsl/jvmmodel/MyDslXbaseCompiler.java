package org.xtext.example.mydsl.jvmmodel;

import org.eclipse.xtext.xbase.XExpression;
import org.eclipse.xtext.xbase.compiler.XbaseCompiler;
import org.eclipse.xtext.xbase.compiler.output.ITreeAppendable;
import org.xtext.example.mydsl.myDsl.XPrintLine;

@SuppressWarnings("all")
public class MyDslXbaseCompiler extends XbaseCompiler {
  @Override
  protected void doInternalToJavaStatement(final XExpression obj, final ITreeAppendable appendable, final boolean isReferenced) {
    if ((obj instanceof XPrintLine)) {
      appendable.trace(obj);
      appendable.append("System.out.println(");
      XExpression _obj = ((XPrintLine)obj).getObj();
      this.internalToJavaExpression(_obj, appendable);
      appendable.append(");");
      appendable.newLine();
      return;
    }
    super.doInternalToJavaStatement(obj, appendable, isReferenced);
  }
}
