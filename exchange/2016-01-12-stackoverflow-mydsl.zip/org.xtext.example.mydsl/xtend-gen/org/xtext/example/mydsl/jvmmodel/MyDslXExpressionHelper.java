package org.xtext.example.mydsl.jvmmodel;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.XExpression;
import org.eclipse.xtext.xbase.util.XExpressionHelper;
import org.xtext.example.mydsl.myDsl.XPrintLine;

@SuppressWarnings("all")
public class MyDslXExpressionHelper extends XExpressionHelper {
  @Override
  public boolean hasSideEffects(final XExpression expr) {
    boolean _xblockexpression = false;
    {
      boolean _or = false;
      if ((expr instanceof XPrintLine)) {
        _or = true;
      } else {
        EObject _eContainer = expr.eContainer();
        _or = (_eContainer instanceof XPrintLine);
      }
      if (_or) {
        return true;
      }
      _xblockexpression = super.hasSideEffects(expr);
    }
    return _xblockexpression;
  }
}
