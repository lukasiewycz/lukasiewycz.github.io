/**
 */
package org.xtext.example.mydsl.myDsl;

import org.eclipse.xtext.xbase.XExpression;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>XPrint Line</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.example.mydsl.myDsl.XPrintLine#getObj <em>Obj</em>}</li>
 * </ul>
 *
 * @see org.xtext.example.mydsl.myDsl.MyDslPackage#getXPrintLine()
 * @model
 * @generated
 */
public interface XPrintLine extends XExpression
{
  /**
   * Returns the value of the '<em><b>Obj</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Obj</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Obj</em>' containment reference.
   * @see #setObj(XExpression)
   * @see org.xtext.example.mydsl.myDsl.MyDslPackage#getXPrintLine_Obj()
   * @model containment="true"
   * @generated
   */
  XExpression getObj();

  /**
   * Sets the value of the '{@link org.xtext.example.mydsl.myDsl.XPrintLine#getObj <em>Obj</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Obj</em>' containment reference.
   * @see #getObj()
   * @generated
   */
  void setObj(XExpression value);

} // XPrintLine
